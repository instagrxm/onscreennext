<?php

if (!function_exists('Ratchet\Client\connect')) {
    require __DIR__ . '/functions.php';
}